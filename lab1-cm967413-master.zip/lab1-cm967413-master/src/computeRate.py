from scapy.config import conf
conf.ipv6_enabled = False
from scapy.all import *
import sys

# get path of pcap file
INPUTPATH = ["../out/TCP_h3.pcap","../out/TCP_h4.pcap","../out/UDP_h3.pcap","../out/UDP_h4.pcap"]



# read pcap
packets = []
for flow in INPUTPATH:
    packets.append(rdpcap(flow))
size_flow1 = 0
size_flow2 = 0
size_flow3 = 0
UDP_size_flow1 = 0
UDP_size_flow2 = 0
UDP_size_flow3 = 0
for i in range(4):
    count2 = 0
    for packet in packets[i][TCP]:
        count2 += 1
    for q in range(count2) :
        print packets[i][TCP][q].time
    if count2 >0 :
        print "number of TCP packets: ", count2
        print "***Print all TCP packets in this pcap file***"
        print packets[i][TCP].show()
        print "***Print the first TCP packet content***"
        print packets[i][TCP][0].show()
        print "***Get data of this packet***"
        print "src IP: ", packets[i][TCP][0][1].src # in IP layer
        print "dst IP: ", packets[i][TCP][0][1].dst # in IP layer
        print "src port: ", packets[i][TCP][0][2].sport # in TCP layer
        print "dst port: ", packets[i][TCP][0][2].dport # in TCP layer
        print "packet size: ", len(packets[i][TCP][0]), " bytes"
        print "***Count number of TCP packets***"
        print "Number of TCP packets : ",count2
        print "***Print the last TCP content***"
        print packets[i][TCP][count2-1].show()
    
        time = packets[i][TCP][count2-1].time - packets[i][TCP][0].time
    
        for m in range(count2) :
            if packets[i][TCP][m][2].dport == 7777 :
                size_flow1 += len(packets[i][TCP][m][2])
            if packets[i][TCP][m][2].dport == 7788 :
                size_flow2 += len(packets[i][TCP][m][2])
            if packets[i][TCP][m][2].dport == 7766 :
                size_flow3 += len(packets[i][TCP][m][2])
    if count2 <=0 :
        count = 0
        for packet in packets[i][UDP]:
            count += 1
        for w in range(count) :
            print packets[i][UDP][w].time
        print "number of UDP packets: ", count
        print "***Print all UDP packets in this pcap file***"
        print packets[i][UDP].show()
        print "***Print the first UDP packet content***"
        print packets[i][UDP][0].show()
        print "***Get data of this packet***"
        print "src IP: ", packets[i][UDP][0][1].src # in IP layer
        print "dst IP: ", packets[i][UDP][0][1].dst # in IP layer
        print "src port: ", packets[i][UDP][0][2].sport # in TCP layer
        print "dst port: ", packets[i][UDP][0][2].dport # in TCP layer
        print "***Count number of UDP packets***"
        time = packets[i][UDP][count-1].time - packets[i][UDP][0].time
        for n in range(count) :
            if packets[i][UDP][n][2].dport == 7777 :
                UDP_size_flow1 += len(packets[i][UDP][n][2])
            if packets[i][UDP][n][2].dport == 7766 :
                UDP_size_flow2 += len(packets[i][UDP][n][2])
            if packets[i][UDP][n][2].dport == 7755 :
                UDP_size_flow3 += len(packets[i][UDP][n][2])
final = float(UDP_size_flow1)*8/1000000
final2 = float(UDP_size_flow2)*8/1000000
final3 = float(UDP_size_flow3)*8/1000000

size1 = float(size_flow1)*8/1000000
size2 = float(size_flow2)*8/1000000
size3 = float(size_flow3)*8/1000000            
print "--- TCP ---"
print"Flow1(h1->h3):  ",size1/time," Mbps"
print"Flow2(h1->h3):  ",size2/time," Mbps"
print"Flow3(h1->h3):  ",size3/time," Mbps"
print "--- UDP ---"
print"Flow1(h1->h3):  ",final/time," Mbps"
print"Flow2(h1->h3):  ",final2/time," Mbps"
print"Flow3(h1->h3):  ",final3/time," Mbps"


