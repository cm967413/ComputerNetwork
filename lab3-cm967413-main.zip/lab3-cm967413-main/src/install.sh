#! /bin/bash


export LC_ALL=C

pip install numpy==1.16

service openvswitch-switch start
